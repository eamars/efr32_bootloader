// *******************************************************************
// * relay-control-client.c
// *
// *
// * Copyright 2012 by Ember Corporation. All rights reserved.              *80*
// *******************************************************************

// this file contains all the common includes for clusters in the util
#include "app/framework/include/af.h"
#include "app/framework/plugin/relay-control-client/relay-control-client.h"

bool emberAfRelayControlClusterGetRelayStateResponseCallback(bool isEnabled)
{
  emberAfRelayControlClusterPrintln("Relay: %p", (isEnabled ? "on" : "off"));

  emberAfSendImmediateDefaultResponse(EMBER_ZCL_STATUS_SUCCESS);
  return true;
}

void emberAfPluginRelayControlClientSendSetRelayState(EmberNodeId nodeId,
                                                      uint8_t srcEndpoint,
                                                      uint8_t dstEndpoint,
                                                      bool isEnabled,
                                                      uint32_t magicNumber)
{
  EmberStatus status;
  emberAfFillCommandRelayControlClusterSetRelayState(isEnabled,
                                                     magicNumber);
  emberAfSetCommandEndpoints(srcEndpoint, dstEndpoint);
  status = emberAfSendCommandUnicast(EMBER_OUTGOING_DIRECT, nodeId);
  if(status != EMBER_SUCCESS) {
    emberAfRelayControlClusterPrintln("Error in send set relay state %x", status);
  }
}
